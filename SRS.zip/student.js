document.addEventListener('DOMContentLoaded', loadStudents);

// Event listener for form submission
document.getElementById('studentForm').addEventListener('submit', function(event) {
  event.preventDefault();
  
  const name = document.getElementById('name').value;
  const id = document.getElementById('id').value;
  const email = document.getElementById('email').value;
  const contact = document.getElementById('contact').value;

  const student = { name, id, email, contact };

  // Store the student in localStorage
  let students = JSON.parse(localStorage.getItem('students')) || [];
  students.push(student);
  localStorage.setItem('students', JSON.stringify(students));

  // Display the student on the page
  addStudentToDOM(student, students.length - 1);

  // Reset the form
  document.getElementById('studentForm').reset();
});

// Function to add student data to the page
function addStudentToDOM(student, index) {
  const studentDiv = document.createElement('div');
  studentDiv.classList.add('student-entry');
  studentDiv.setAttribute('data-index', index);

  studentDiv.innerHTML = `
    <p><strong>Name:</strong> ${student.name}</p>
    <p><strong>id:</strong> ${student.id}</p>
    <p><strong>Email:</strong> ${student.email}</p>
    <p><strong>Contact:</strong> ${student.contact}</p>
    <button class="delete-btn">Delete</button>
  `;

  // Add delete functionality
  studentDiv.querySelector('.delete-btn').addEventListener('click', function() {
    deleteStudent(index);
  });

  document.getElementById('studentList').appendChild(studentDiv);
}

// Function to load students from localStorage and display them
function loadStudents() {
  const students = JSON.parse(localStorage.getItem('students')) || [];
  students.forEach((student, index) => addStudentToDOM(student, index));
}

// Function to delete a student from the page and localStorage
function deleteStudent(index) {
  let students = JSON.parse(localStorage.getItem('students')) || [];
  students.splice(index, 1); // Remove the student from the array

  // Update the localStorage
  localStorage.setItem('students', JSON.stringify(students));

  // Reload the displayed student list
  document.getElementById('studentList').innerHTML = '';
  loadStudents(); // Refresh the list
}

// Event listener for reset button to clear form inputs
document.getElementById('resetBtn').addEventListener('click', function() {
  document.getElementById('studentForm').reset();
});